function myFunction() {
    return "Hello World!"; 
}
document.getElementById("text1").innerHTML = myFunction(); 