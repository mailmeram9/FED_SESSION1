x = 6;
y = 3;

document.getElementById("addBtn").onclick = function add() {
	var z= x + y;
  	alert(z);
}
document.getElementById("subBtn").onclick = function sub() {
	var z= x - y;
  	alert(z);
}
document.getElementById("multiplyBtn").onclick = function multiply() {
	var z= x * y;
  	alert(z);
}
document.getElementById("divBtn").onclick = function div() {
	var z= x / y;
  	alert(z);
}
